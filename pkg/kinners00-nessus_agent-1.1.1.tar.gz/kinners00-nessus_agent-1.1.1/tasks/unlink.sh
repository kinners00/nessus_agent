#!/bin/bash

/opt/nessus_agent/sbin/nessuscli agent unlink