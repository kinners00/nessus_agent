# Changelog

All notable changes to this project will be documented in this file.

## Release 1.1.1

**Features**
Functionality: Added ```nessus_agent::generatelogs``` task and plan to enable generation of logs on targets as well as a workflow in the plan which generates logs and downloads them to your bolt workstation.

Docs: Addition to include info on how to get started with bolt for first time users pointing towards a bolt "sandbox" project pre-populated with everything you need to get started.

Added detail around how to run as root to ensure tasks and plans execute successfully.

Relevant usage info about new task and plan.

**Bugfixes**

**Known Issues**
